---
pdf_options:
  format: Letter
  margin: 24mm 18mm
  printBackground: true
  headerTemplate: |-
    <style>section { margin: 0 auto; font-family: -apple-system, system-ui, sans-serif; font-size: 9px; color: #6b7280; width: 100%; padding: 0 24px; display:flex; justify-content: space-between; }</style>
    <section><span>L3xy — Technical Guidebook (NDA)</span><span>Confidential</span></section>
  footerTemplate: |-
    <style>section { margin: 0 auto; font-family: -apple-system, system-ui, sans-serif; font-size: 9px; color: #6b7280; width: 100%; padding: 0 24px; display:flex; justify-content: space-between; }</style>
    <section><span>© L3xy Inc. — Distribution restricted to NDA signatories</span><span><span class="pageNumber"></span> / <span class="totalPages"></span></span></section>
  displayHeaderFooter: true
stylesheet_encoding: utf-8
body_class: l3xy-doc
css: |-
  .l3xy-doc { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, system-ui, sans-serif; color: #0f172a; line-height: 1.55; font-size: 11pt; }
  .l3xy-doc h1 { color: #0e7490; font-size: 24pt; border-bottom: 3px solid #06b6d4; padding-bottom: 6px; margin-top: 28px; }
  .l3xy-doc h2 { color: #0891b2; font-size: 16pt; margin-top: 26px; border-left: 4px solid #06b6d4; padding-left: 10px; }
  .l3xy-doc h3 { color: #0f172a; font-size: 13pt; margin-top: 18px; }
  .l3xy-doc h4 { color: #475569; font-size: 11pt; margin-top: 14px; text-transform: uppercase; letter-spacing: 0.5px; }
  .l3xy-doc table { border-collapse: collapse; width: 100%; margin: 12px 0; font-size: 10pt; }
  .l3xy-doc th { background: #ecfeff; color: #0e7490; text-align: left; padding: 8px 10px; border-bottom: 2px solid #06b6d4; }
  .l3xy-doc td { padding: 7px 10px; border-bottom: 1px solid #e2e8f0; vertical-align: top; }
  .l3xy-doc blockquote { background: #f0fdfa; border-left: 4px solid #14b8a6; padding: 10px 14px; color: #134e4a; margin: 14px 0; }
  .l3xy-doc code { background: #f1f5f9; padding: 1px 5px; border-radius: 3px; font-size: 9.5pt; }
  .l3xy-doc pre { background: #0f172a; color: #e2e8f0; padding: 12px 16px; border-radius: 6px; font-size: 9.5pt; overflow-x: auto; }
  .l3xy-doc pre code { background: transparent; color: inherit; padding: 0; }
  .l3xy-doc hr { border: none; border-top: 1px dashed #cbd5e1; margin: 28px 0; }
  .l3xy-doc .cover { text-align: center; padding: 60px 0 30px; }
  .l3xy-doc .cover h1 { border: none; font-size: 42pt; color: #06b6d4; margin: 0; }
  .l3xy-doc .cover .subtitle { font-size: 13pt; color: #475569; margin-top: 8px; letter-spacing: 1px; text-transform: uppercase; }
  .l3xy-doc .cover .tag { display:inline-block; margin-top: 24px; background: #0f172a; color:#06b6d4; padding: 6px 14px; border-radius: 999px; font-size: 10pt; border: 1px solid #06b6d4; }
  .l3xy-doc .nda { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; padding: 14px 18px; border-radius: 6px; margin: 30px 0; font-size: 10pt; }
---

<div class="cover">

# L3xy

<div class="subtitle">Technical Guidebook · Internal & NDA Partners</div>

<div class="tag">Confidential · 2026 Edition</div>

</div>

<div class="nda">

**CONFIDENTIAL — DISTRIBUTION RESTRICTED.** This document contains the proprietary architecture, scoring models, and agent designs of the L3xy platform. Access is limited to L3xy employees, contractors, and partners who have executed a Mutual Non-Disclosure Agreement. Do not forward, copy, or share without written approval from L3xy Inc.

</div>

---

## 1. Executive summary

L3xy is a multi-tenant, autonomous AI hiring platform. It coordinates a team of nine specialized AI agents through a Bayesian intelligence engine that scores, ranks, and recommends actions for every candidate in real time.

The product replaces the manual recruiter workflow (sourcing → screening → outreach → scheduling → interviewing) with a single self-running pipeline that the recruiter steers rather than executes. Every signal the agents produce flows into a composite scoring model that outputs a hire probability, a "next best action," and a full decision audit trail.

This guidebook documents the architecture, the math, the data sources, the agent designs, and the closed-loop learning system that the public overview deck only references.

---

## 2. System architecture

### 2.1 High-level topology

L3xy is a pnpm monorepo with the following deployable artifacts:

| Artifact | Purpose |
|---|---|
| `artifacts/lexy` | Recruiter web app (React + Vite, cyan/dark `#06b6d4 / #050a0f` theme) |
| `artifacts/lexy-site` | Public marketing site |
| `artifacts/lexy-demo` | Sandboxed demo tenant for prospects |
| `artifacts/api-server` | Express API server, agent orchestrator, intelligence engine |
| `lib/db` | Drizzle ORM schema + Postgres migrations (shared) |

### 2.2 Multi-tenant model

- Every row in every business table carries `tenant_id`.
- `resolveUser` middleware enforces tenant isolation on every request.
- Roles: `platform_admin`, `tenant_admin`, `recruiter`, `hiring_manager`.
- Tenant-level policy objects govern automation thresholds (see §6).

### 2.3 Data layer

Postgres with Drizzle ORM. Notable schema decisions:

- `candidates.email` is `NOT NULL` with a partial unique index on `(tenant_id, lower(email)) WHERE email IS NOT NULL` to allow placeholder emails for resume-only candidates while still enforcing dedup on real ones.
- `pipeline_runs` is the source of truth for agent execution; every stage transition is appended as a row in `pipeline_run_stages` with `status`, `startedAt`, `completedAt`, and `outputJson`.
- The intelligence engine reads agent outputs through `signalsJson` columns rather than re-running expensive AI calls.

---

## 3. Agent inventory and execution order

The orchestrator (`artifacts/api-server/src/lib/agents/orchestrator.ts`) coordinates nine production agents in canonical execution order.

### 3.1 Canonical AGENT_ORDER

```
icp(1) → sourcing(2) → screening(3) → verification(4) → outreach(5)
       → scheduling(6) → interview(7) → proctoring(8) → anti-ghosting(9)
```

`analytics` exists as a registered agent (order 99) but is intentionally not part of the runnable pipeline — it is a results dashboard surfaced under the Intelligence tab. Legacy configs that include it are stripped on load.

### 3.2 Dependency graph (UI enforcement)

The frontend `WorkflowCanvas` enforces this DAG when the recruiter toggles agents on/off; selecting any downstream agent automatically pulls in its prerequisites with a toast notification, and disabling an upstream agent cascades to its dependents.

| Agent | Requires |
|---|---|
| sourcing | icp |
| screening | sourcing |
| verification | screening |
| outreach | screening |
| scheduling | outreach |
| interview | scheduling |
| proctoring | interview |
| anti-ghosting | outreach |

### 3.3 Per-agent design

#### ICP Agent
Parses the job description into a structured `IdealCandidateProfile`: required skills, preferred skills, seniority band, industry domain, and weighted attributes. Output is canonical input for sourcing and screening. Uses an LLM with a strict JSON schema and a deterministic temperature.

#### Sourcing Agent
Two-phase architecture:

- **Phase 1 (parallel discovery):** GitHub API, People Data Labs (PDL), and SerpAPI are queried concurrently. PDL queries use Elasticsearch DSL; SerpAPI queries use boolean LinkedIn search strings; GitHub queries hit `/search/users` filtered by language, followers, repo count.
- **Phase 2 (enrichment):** EnrichLayer ingests Phase-1 LinkedIn URLs and resolves them into deep profile records (titles, companies, skills). The enrichment cap is applied on the **output** side, not the input side, to avoid wasting budget on profiles that fail enrichment.

PDL profiles are flattened (`skills.name` → `skills` field) before scoring. `enrichOneProfile` logs every failure with the upstream URL for debuggability.

#### Screening Agent
Resume + profile + ICP → match percentage, gap analysis, structured recruiter summary. Two-pass LLM: first pass extracts structured experience, second pass scores against the ICP using a deterministic rubric. Outputs feed both the candidate Intelligence Card and the bulk pipeline view.

#### Verify Agent
Cross-checks identity using:

- LinkedIn URL match (canonical handle vs. resume handle)
- Resume-to-profile consistency check (employer overlap, date overlap)
- Disposable email and burner phone detection (regex + provider lookup)
- Optional ID-document upload review (manual escalation path)

The orchestrator gate refuses to run Verify if Screening hasn't produced eligible candidates ("No candidates in screening stage ready for verification").

#### Outreach Agent
Multi-step sequence engine. For each candidate:

- Generates personalized first-touch copy using ICP fit reasons
- Selects optimal send time per recipient timezone
- Maintains conversation state across replies
- Hands off to Anti-Ghost when silence thresholds are crossed

#### Schedule Agent
Calendar invite generation, reminder scheduling, timezone normalization. Issues unique interview-room URLs per session. Integrates with the Anti-Ghost agent for reminder cadence.

#### Interview Agent
Conducts AI-led video interviews. Four sub-types share a base agent with track-specific question banks:

- **Behavioral** — STAR-method evaluation
- **Cultural** — tenant-supplied cultural document grounds the questions
- **Technical** — adaptive difficulty (easy / medium / hard / mixed)
- **Programming** — language-aware coding rounds

Eligibility gate (Gate 2 inside `_runInterview`) rejects manual candidates whose `verification_status` is not `"verified"` — enforced because manual uploads can include unvetted profiles.

#### Proctoring Agent
Real-time vision pipeline during the interview session:

- Multi-face detection
- Gaze-direction estimation (off-screen %)
- Tab/visibility-change instrumentation
- Background audio anomaly flags

Outputs an integrity score that feeds the Trust composite.

#### Anti-Ghost Agent
Monitors silence on outreach and post-interview threads. Triggers tiered re-engagement:

1. Auto-friendly nudge (24h)
2. Value-add follow-up (72h)
3. Recruiter escalation with a one-click handoff (>5 days)

Decay-aware so it doesn't pester candidates who responded recently on another channel.

---

## 4. The Intelligence Engine

Lives in `artifacts/api-server/src/lib/intelligence.ts`. This is the core of the platform.

### 4.1 Composite score formula

For every candidate, the engine produces four sub-scores and a single Hire Probability:

| Composite | Weight | Sub-weights |
|---|---|---|
| **Fit Score** | 35% | Skill match 45% · Experience 30% · ICP pattern 25% |
| **Quality Score** | 25% | Screening 40-60% · Interview 40% · Sourcing 20-40% |
| **Trust Score** | 20% | Verification 50% · Proctoring integrity 30% · Fraud risk 20% |
| **Conversion Score** | 20% | Outreach engagement 30% · Ghosting resistance 30% · Scheduling efficiency 40% |

Sub-weights are dynamic: when a contributing agent hasn't run yet, its weight is redistributed to the remaining contributors so the score is never penalized for missing data — it's simply less confident (see §4.3).

### 4.2 Temporal decay

Every signal carries a timestamp. At read time it is decayed by an exponential half-life:

```
weight = 0.5 ^ (ageHours / halfLifeHours)
```

Half-lives are tuned per signal class:

| Signal class | Half-life |
|---|---|
| Anti-Ghost (engagement freshness) | 24 hours |
| Outreach reply velocity | 48 hours |
| Interview performance | 7 days |
| Screening / Sourcing match | 30 days |
| ICP alignment | 90 days |

This means a hot candidate who replied yesterday outranks an identically-qualified candidate who replied last quarter — without us having to re-screen anyone.

### 4.3 Confidence breakdown

Every score ships with a confidence number computed from three factors:

```
confidence = 0.4 * completeness + 0.3 * freshness + 0.3 * criticalCoverage
```

- **Completeness:** fraction of expected agent signals present
- **Freshness:** weighted-average decay factor across all contributing signals
- **Critical coverage:** fraction of high-leverage signals (verification, interview, screening) that are present

Recruiters see confidence as a small badge next to each score. Low-confidence high-probability candidates surface a "needs more signal" tooltip.

### 4.4 Hire Probability — Bayesian formulation

The hire gauge is the posterior probability:

```
P(hire | signals) ∝ P(signals | hire) * P(hire)
```

Implemented as a logistic combiner over the four composites with tenant-trained coefficients:

```
logit(p) = β0 + β_fit * fit + β_quality * quality
            + β_trust * trust + β_conversion * conversion
```

The `β` coefficients start at the platform-trained defaults and update per tenant via the closed-loop learning system (§7).

### 4.5 Stage-transition forecasts

Beyond hire probability, the engine emits three secondary forecasts:

- `nextStageSuccess` — probability the candidate clears the next pipeline stage
- `offerAcceptance` — probability they accept an offer if extended
- `dropoffProbability` — probability they ghost in the next 7 days

These power the "Lexy Candidate Prediction" plain-language summary on the candidate card.

### 4.6 Next Best Action waterfall

The recommendation engine is a deterministic waterfall over the scores and the tenant policy:

```
if trust < tenantPolicy.lowTrustThreshold
    → "Verify"
else if dropoffProbability > tenantPolicy.ghostingAlert
    → "Re-engage"
else if hireProbability >= tenantPolicy.advanceThreshold
    → "Advance"
else if quality < tenantPolicy.qualityFloor and screening_done
    → "Reject"
else
    → "Schedule"
```

The waterfall order is intentional: integrity issues short-circuit anything else, ghosting risk preempts advancement, and rejections require completed screening to avoid premature negative decisions.

---

## 5. The Connection Strength Engine

A separate engine (`lib/connectionEngine.ts`) tracks behavioral engagement signals distinct from fit:

| Event | Δ Connection |
|---|---|
| Reply within 24h | +15 |
| Schedules interview voluntarily | +20 |
| Completes interview | +25 |
| Asks a question back | +5 |
| No-show | -25 |
| Cancels < 2h before | -15 |
| Goes silent > 5 days | -10 |

Connection strength feeds the Conversion composite and powers the Anti-Ghost tier-escalation logic. It's exposed as a signal on the candidate card so recruiters can see *why* a hot candidate has a high conversion score even if their fit is mid-tier.

---

## 6. Tenant decision policies

Every tenant configures a `DecisionPolicy` document (`lib/policies.ts`):

| Field | Default | Purpose |
|---|---|---|
| `advanceThreshold` | 80 | Minimum hire probability to auto-advance |
| `qualityFloor` | 40 | Below this, suggest reject after screening |
| `lowTrustThreshold` | 50 | Force verification before any advance |
| `ghostingAlert` | 60 | Trigger re-engage NBA |
| `requireRecruiterApproval` | true | All advances must be human-confirmed |
| `lowTrustAction` | `"manual_verification"` | What to do on integrity flags |
| `autoRunAgents` | `[]` | Agents allowed to fire without recruiter trigger |

Policies are versioned and every NBA decision records the policy snapshot that produced it, so the audit trail is reproducible even after a policy change.

---

## 7. Closed-loop learning

L3xy is not a static scoring model. Every recruiter override and every hiring outcome feeds back into the system.

### 7.1 Override capture

When a recruiter accepts, modifies, or rejects an NBA, the decision is appended to `overridesJson` on the candidate row with:

- The recommended action
- The recruiter's actual action
- The composite scores at decision time
- The policy snapshot
- Free-text reason (optional)

### 7.2 Outcome correlation

`routes/learning.ts` periodically computes per-tenant precision and recall metrics:

```
precision = hires_predicted_correctly / total_advance_recommendations
recall    = hires_predicted_correctly / total_hires
```

It also computes **Agent Coverage Impact** — hire rate for candidates who passed through each agent vs. hire rate for those who skipped it — which surfaces in the Analytics tab as recommendations like *"Lower your advance threshold to reduce manual review overhead."*

### 7.3 Coefficient updates

The logistic `β` coefficients in §4.4 are re-fit per tenant nightly using the candidate population that has reached a terminal outcome (Hired or Rejected). This produces a tenant-specific scoring model without retraining the underlying LLMs.

### 7.4 Drift detection

`Override Rate` (recruiter disagreement %) is monitored continuously. A sustained spike triggers a calibration alert in the Analytics tab indicating the model has drifted relative to the tenant's actual hiring behavior.

---

## 8. External data sources

| Source | Role | Notes |
|---|---|---|
| **People Data Labs (PDL)** | Primary 500M+ profile database | Elasticsearch DSL queries; `skills.name` flattening required |
| **EnrichLayer** | Phase-2 LinkedIn URL enricher | Output-side cap, per-URL failure logging |
| **SerpAPI** | Boolean LinkedIn discovery | Used when PDL coverage is sparse |
| **GitHub API** | Engineering-role discovery | `/search/users` with language + repo + follower filters |
| **OpenAI / Anthropic** | LLM inference | Routed through Replit-managed AI integrations |

Sourcing budget is spent in this priority order: GitHub (free) → SerpAPI → PDL → EnrichLayer (most expensive, applied to top candidates only).

---

## 9. Recruiter UX surfaces

### 9.1 Job dashboard
- WorkflowCanvas with the 9-stage agent strip in canonical order
- Real-time pipeline status, viable count, target progress
- Auto-run toggle for unattended pipelines

### 9.2 Candidate profile
- Intelligence Card (scores, gauge, NBA, strengths/risks, prediction)
- Decision Audit Trail with every signal and policy snapshot
- Stage-transition forecasts
- Conversation history across all channels

### 9.3 Outreach inbox
- Unified thread view across email/LinkedIn/SMS
- AI-drafted replies with sentiment analysis
- Connection strength inline per thread

### 9.4 Interview room
- Live AI interviewer with adaptive question selection
- Real-time transcript and STAR evaluation
- Proctoring integrity flags as they happen
- Recording + transcript stored against the candidate

### 9.5 Decision Queue
- Recruiter approval surface for "Advance" recommendations
- One-click accept / modify / reject with reason capture
- Bulk-action support for high-confidence batches

### 9.6 Analytics dashboard
- Funnel breakdown across all 9 stages
- Bottleneck detection (median time per stage)
- Calibration: precision/recall/override rate
- Agent Coverage Impact
- Learning Recommendations

---

## 10. Engineering "secret sauce"

A short list of design choices that distinguish L3xy from the competition:

1. **Two-phase sourcing with output-side cap.** Most competitors enrich every profile they discover, blowing the budget on dead-ends. L3xy only spends enrichment dollars on profiles that survive Phase-1 ranking.

2. **Additive signal merging, not replacement.** Each agent appends to a candidate's signal vector — none overwrite prior signals. This means any agent can fire independently without losing historical context, and the engine can score a candidate even when only 3 of 9 agents have run.

3. **Decay-weighted confidence, not just decay-weighted scores.** Stale signals lose weight in the *score*, but they also lower the *confidence*, so recruiters see a real "this needs more data" signal rather than a deceptively crisp number.

4. **Dependency-graph pipeline builder.** The recruiter cannot construct an invalid pipeline (e.g. Verify without Screening). The UI auto-pulls prerequisites and persists the healed config — fixing not just the next run, but every legacy config saved before the rule existed.

5. **Per-tenant logistic coefficients.** The hire-probability model is platform-trained but tenant-calibrated. Two tenants hiring the same role can get different hire probabilities for the same candidate because their bar is different.

6. **NBA waterfall with policy snapshotting.** Every recommendation is reproducible from the snapshot — auditors and compliance teams can trace any decision to the exact policy state that produced it.

7. **Connection Strength as a first-class engine.** Behavioral signals (replies, no-shows, voluntary scheduling) are tracked separately from fit and feed the Conversion composite explicitly — making the difference between "qualified but cold" and "qualified and engaged" visible.

8. **Closed-loop coefficient updates without LLM retraining.** Nightly logistic re-fit is cheap, fast, and lets the system improve daily without paying for fine-tuning.

---

## 11. Roadmap (NDA partners)

- **Q3:** Greenhouse + Lever ATS bidirectional sync
- **Q3:** Native Google / Microsoft / Apple calendar
- **Q4:** Mobile recruiter app (Expo)
- **Q4:** Custom-agent SDK for tenant-supplied evaluators
- **Q4:** Take-home and system-design interview formats
- **Early next year:** Tenant-trained ICP foundation model (replacing per-job ICP prompt) for sub-second pipeline launch

---

## 12. Glossary

| Term | Definition |
|---|---|
| **ICP** | Ideal Candidate Profile — structured spec extracted from a JD |
| **NBA** | Next Best Action — engine's recommended action for a candidate |
| **Composite Score** | One of Fit / Quality / Trust / Conversion |
| **Hire Probability** | Bayesian posterior $P(\text{hire} \mid \text{signals})$ |
| **Connection Strength** | Behavioral engagement score, distinct from Fit |
| **Decision Audit Trail** | Reproducible log of signals + policy → decision |
| **Override** | Recruiter accept/modify/reject of an NBA |
| **Calibration Drift** | Sustained increase in Override Rate signaling model staleness |

---

> **L3xy Inc. — Confidential.** Distribution restricted to NDA signatories.
> Questions: engineering@l3xy.io · founders@l3xy.io
